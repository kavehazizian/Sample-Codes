from __future__ import annotations

import json
import os
import secrets
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any

from flask import (
    Flask,
    abort,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)


BASE_DIR = Path(__file__).resolve().parent
PRODUCTS_PATH = BASE_DIR / "products.json"
ORDERS_PATH = BASE_DIR / "instance" / "orders.json"


@dataclass(frozen=True)
class Product:
    slug: str
    name: str
    category: str
    price_cents: int
    description: str
    image_style: str
    tags: list[str]
    stock: int
    featured: bool = False

    @property
    def price(self) -> Decimal:
        return Decimal(self.price_cents) / Decimal(100)

    @property
    def price_label(self) -> str:
        return money(self.price_cents)


def create_app() -> Flask:
    app = Flask(__name__, instance_relative_config=True)
    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret-change-me")
    app.config["SHOP_EMAIL"] = os.getenv("SHOP_EMAIL", "hello@unclegooli.example")
    app.config["SHIPPING_CENTS"] = int(os.getenv("SHIPPING_CENTS", "500"))
    app.config["FREE_SHIPPING_CENTS"] = int(os.getenv("FREE_SHIPPING_CENTS", "7500"))
    app.instance_path and Path(app.instance_path).mkdir(parents=True, exist_ok=True)

    @app.template_filter("money")
    def money_filter(cents: int) -> str:
        return money(cents)

    @app.context_processor
    def inject_globals() -> dict[str, Any]:
        products = load_products()
        cart = get_cart()
        cart_count = sum(cart.values())
        subtotal = cart_subtotal(products, cart)
        return {
            "cart_count": cart_count,
            "cart_preview": build_cart_items(products, cart),
            "cart_subtotal": subtotal,
            "cart_shipping": shipping_for(subtotal, app.config["SHIPPING_CENTS"], app.config["FREE_SHIPPING_CENTS"]),
            "free_shipping_cents": app.config["FREE_SHIPPING_CENTS"],
            "shop_email": app.config["SHOP_EMAIL"],
        }

    @app.route("/")
    def index():
        products = load_products()
        active_category = request.args.get("category", "All products")
        active_price = request.args.get("price", "any")
        query = request.args.get("q", "").strip()
        sort = request.args.get("sort", "featured")

        filtered = filter_products(products, active_category, active_price, query)
        filtered = sort_products(filtered, sort)
        categories = ["All products"] + sorted({product.category for product in products})

        return render_template(
            "index.html",
            products=filtered,
            all_products=products,
            categories=categories,
            active_category=active_category,
            active_price=active_price,
            query=query,
            sort=sort,
        )

    @app.post("/cart/add/<slug>")
    def add_to_cart(slug: str):
        product = product_by_slug(slug)
        if product is None:
            abort(404)

        cart = get_cart()
        current_quantity = cart.get(slug, 0)
        if current_quantity >= product.stock:
            flash(f"{product.name} has only {product.stock} available.", "warning")
        else:
            cart[slug] = current_quantity + 1
            session["cart"] = cart
            flash(f"Added {product.name} to your cart.", "success")
        return redirect_back()

    @app.post("/cart/update/<slug>")
    def update_cart(slug: str):
        product = product_by_slug(slug)
        if product is None:
            abort(404)

        action = request.form.get("action")
        cart = get_cart()
        quantity = cart.get(slug, 0)

        if action == "increase":
            quantity = min(quantity + 1, product.stock)
        elif action == "decrease":
            quantity = max(quantity - 1, 0)
        elif action == "remove":
            quantity = 0
        else:
            try:
                quantity = max(0, min(int(request.form.get("quantity", "0")), product.stock))
            except ValueError:
                quantity = cart.get(slug, 0)

        if quantity:
            cart[slug] = quantity
        else:
            cart.pop(slug, None)

        session["cart"] = cart
        flash("Cart updated.", "success")
        return redirect_back(url_for("cart"))

    @app.post("/cart/clear")
    def clear_cart():
        session["cart"] = {}
        flash("Your cart is clear.", "success")
        return redirect_back(url_for("index"))

    @app.route("/cart")
    def cart():
        products = load_products()
        cart_data = get_cart()
        subtotal = cart_subtotal(products, cart_data)
        shipping = shipping_for(subtotal, app.config["SHIPPING_CENTS"], app.config["FREE_SHIPPING_CENTS"])
        return render_template(
            "cart.html",
            items=build_cart_items(products, cart_data),
            subtotal=subtotal,
            shipping=shipping,
            total=subtotal + shipping,
        )

    @app.route("/checkout", methods=["GET", "POST"])
    def checkout():
        products = load_products()
        cart_data = get_cart()
        items = build_cart_items(products, cart_data)

        if not items:
            flash("Add something to your cart before checkout.", "warning")
            return redirect(url_for("index"))

        subtotal = cart_subtotal(products, cart_data)
        shipping = shipping_for(subtotal, app.config["SHIPPING_CENTS"], app.config["FREE_SHIPPING_CENTS"])
        errors: dict[str, str] = {}
        form = {
            "name": request.form.get("name", "").strip(),
            "email": request.form.get("email", "").strip(),
            "phone": request.form.get("phone", "").strip(),
            "address": request.form.get("address", "").strip(),
            "notes": request.form.get("notes", "").strip(),
        }

        if request.method == "POST":
            required_fields = {
                "name": "Name is required.",
                "email": "Email is required.",
                "phone": "Phone is required.",
                "address": "Delivery address is required.",
            }
            for field, message in required_fields.items():
                if not form[field]:
                    errors[field] = message
            if form["email"] and "@" not in form["email"]:
                errors["email"] = "Enter a valid email address."

            if not errors:
                order = save_order(
                    {
                        "id": make_order_id(),
                        "created_at": datetime.now(timezone.utc).isoformat(),
                        "customer": form,
                        "items": [
                            {
                                "slug": item["product"].slug,
                                "name": item["product"].name,
                                "quantity": item["quantity"],
                                "unit_price_cents": item["product"].price_cents,
                                "line_total_cents": item["line_total"],
                            }
                            for item in items
                        ],
                        "subtotal_cents": subtotal,
                        "shipping_cents": shipping,
                        "total_cents": subtotal + shipping,
                        "status": "received",
                    }
                )
                session["cart"] = {}
                flash("Order received. We'll contact you soon to confirm payment and delivery.", "success")
                return redirect(url_for("order_confirmed", order_id=order["id"]))

        return render_template(
            "checkout.html",
            items=items,
            subtotal=subtotal,
            shipping=shipping,
            total=subtotal + shipping,
            form=form,
            errors=errors,
        )

    @app.route("/order/<order_id>")
    def order_confirmed(order_id: str):
        order = find_order(order_id)
        if order is None:
            abort(404)
        return render_template("order_confirmed.html", order=order)

    @app.route("/orders")
    def orders():
        order_id = request.args.get("order_id", "").strip()
        order = find_order(order_id) if order_id else None
        not_found = bool(order_id and order is None)
        return render_template("orders.html", order=order, order_id=order_id, not_found=not_found)

    @app.route("/owner/orders", methods=["GET", "POST"])
    def owner_orders():
        admin_pin = os.getenv("ADMIN_PIN")
        if not admin_pin:
            return render_template("owner_orders.html", orders=[], locked=True, pin_configured=False)

        unlocked = session.get("owner_unlocked") is True
        if request.method == "POST":
            if request.form.get("pin") == admin_pin:
                session["owner_unlocked"] = True
                unlocked = True
            else:
                flash("That PIN did not match.", "warning")

        if not unlocked:
            return render_template("owner_orders.html", orders=[], locked=True, pin_configured=True)

        orders_data = sorted(load_orders(), key=lambda order: order["created_at"], reverse=True)
        return render_template("owner_orders.html", orders=orders_data, locked=False, pin_configured=True)

    @app.errorhandler(404)
    def not_found(_error):
        return render_template("404.html"), 404

    return app


def load_products() -> list[Product]:
    with PRODUCTS_PATH.open(encoding="utf-8") as product_file:
        raw_products = json.load(product_file)
    return [Product(**product) for product in raw_products]


def product_by_slug(slug: str) -> Product | None:
    return next((product for product in load_products() if product.slug == slug), None)


def filter_products(
    products: list[Product],
    category: str,
    price_filter: str,
    query: str,
) -> list[Product]:
    filtered = products
    if category != "All products":
        filtered = [product for product in filtered if product.category == category]

    if price_filter == "under-10":
        filtered = [product for product in filtered if product.price_cents < 1000]
    elif price_filter == "10-25":
        filtered = [product for product in filtered if 1000 <= product.price_cents <= 2500]
    elif price_filter == "25-50":
        filtered = [product for product in filtered if 2500 < product.price_cents <= 5000]
    elif price_filter == "over-50":
        filtered = [product for product in filtered if product.price_cents > 5000]

    if query:
        query_lower = query.lower()
        filtered = [
            product
            for product in filtered
            if query_lower in product.name.lower()
            or query_lower in product.description.lower()
            or any(query_lower in tag.lower() for tag in product.tags)
        ]

    return filtered


def sort_products(products: list[Product], sort: str) -> list[Product]:
    if sort == "price-low":
        return sorted(products, key=lambda product: product.price_cents)
    if sort == "price-high":
        return sorted(products, key=lambda product: product.price_cents, reverse=True)
    if sort == "name":
        return sorted(products, key=lambda product: product.name)
    return sorted(products, key=lambda product: (not product.featured, product.name))


def get_cart() -> dict[str, int]:
    raw_cart = session.get("cart", {})
    if not isinstance(raw_cart, dict):
        return {}

    cart: dict[str, int] = {}
    for slug, quantity in raw_cart.items():
        try:
            parsed_quantity = int(quantity)
        except (TypeError, ValueError):
            continue
        if parsed_quantity > 0:
            cart[str(slug)] = parsed_quantity
    return cart


def build_cart_items(products: list[Product], cart: dict[str, int]) -> list[dict[str, Any]]:
    products_by_slug = {product.slug: product for product in products}
    items: list[dict[str, Any]] = []
    for slug, quantity in cart.items():
        product = products_by_slug.get(slug)
        if not product:
            continue
        items.append(
            {
                "product": product,
                "quantity": quantity,
                "line_total": product.price_cents * quantity,
            }
        )
    return items


def cart_subtotal(products: list[Product], cart: dict[str, int]) -> int:
    return sum(item["line_total"] for item in build_cart_items(products, cart))


def shipping_for(subtotal_cents: int, shipping_cents: int, free_shipping_cents: int) -> int:
    if subtotal_cents <= 0 or subtotal_cents >= free_shipping_cents:
        return 0
    return shipping_cents


def money(cents: int) -> str:
    return f"${Decimal(cents) / Decimal(100):,.2f}"


def make_order_id() -> str:
    return f"UG-{datetime.now(timezone.utc):%Y%m%d}-{secrets.token_hex(3).upper()}"


def load_orders() -> list[dict[str, Any]]:
    if not ORDERS_PATH.exists():
        return []
    with ORDERS_PATH.open(encoding="utf-8") as order_file:
        try:
            data = json.load(order_file)
        except json.JSONDecodeError:
            return []
    return data if isinstance(data, list) else []


def save_order(order: dict[str, Any]) -> dict[str, Any]:
    ORDERS_PATH.parent.mkdir(parents=True, exist_ok=True)
    orders = load_orders()
    orders.append(order)
    with ORDERS_PATH.open("w", encoding="utf-8") as order_file:
        json.dump(orders, order_file, indent=2)
    return order


def find_order(order_id: str) -> dict[str, Any] | None:
    if not order_id:
        return None
    return next((order for order in load_orders() if order.get("id") == order_id), None)


def redirect_back(fallback: str | None = None):
    return redirect(request.headers.get("Referer") or fallback or url_for("index"))


app = create_app()


if __name__ == "__main__":
    app.run(debug=True)
