# Uncle Gooli Store

A small Python/Flask storefront for selling products under the **Uncle Gooli** name.

It includes:

- Product catalog with search, categories, price filters, and sorting
- Session-based cart with quantity controls
- Checkout/contact order form
- Local JSON order storage in `instance/orders.json`
- Optional owner order board protected by `ADMIN_PIN`
- Deployment files for PythonAnywhere or any Gunicorn-compatible free PaaS

## Run locally

```powershell
cd uncle-gooli-store
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:SECRET_KEY="change-this-to-a-random-value"
$env:ADMIN_PIN="1234"
flask --app app run --debug
```

Open <http://127.0.0.1:5000>.

## Edit products

Change names, prices, categories, stock, and descriptions in `products.json`.
Prices are stored in cents, so `$16.00` is `1600`.

## Free cloud deployment: PythonAnywhere

PythonAnywhere's free Beginner account supports one Python web app at
`your-username.pythonanywhere.com`. The official Flask guide recommends importing
an existing app with manual configuration and a virtualenv.

1. Upload this `uncle-gooli-store` folder to `/home/yourusername/uncle-gooli-store`.
2. Open a Bash console on PythonAnywhere:

   ```bash
   cd ~/uncle-gooli-store
   mkvirtualenv --python=/usr/bin/python3.13 uncle-gooli
   pip install -r requirements.txt
   ```

3. In the PythonAnywhere **Web** tab, add a new app with **Manual configuration**.
4. Set the virtualenv to `/home/yourusername/.virtualenvs/uncle-gooli`.
5. Edit the WSGI file:

   ```python
   import sys

   path = "/home/yourusername/uncle-gooli-store"
   if path not in sys.path:
       sys.path.insert(0, path)

   from app import app as application
   ```

6. Add environment variables in the Web tab if available, or in the WSGI file before import:

   ```python
   import os
   os.environ["SECRET_KEY"] = "make-this-a-long-random-secret"
   os.environ["ADMIN_PIN"] = "choose-a-private-pin"
   os.environ["SHOP_EMAIL"] = "you@example.com"
   ```

7. Reload the web app.

Official references:

- PythonAnywhere Flask setup: <https://help.pythonanywhere.com/pages/Flask/>
- PythonAnywhere pricing/free Beginner plan: <https://www.pythonanywhere.com/pricing/>

## Generic free PaaS deployment

This project also includes a `Procfile`:

```text
web: gunicorn app:app
```

On hosts that support Python buildpacks, set these environment variables:

- `SECRET_KEY`: long random value
- `ADMIN_PIN`: private PIN for `/owner/orders`
- `SHOP_EMAIL`: public contact email
- `SHIPPING_CENTS`: optional, default `500`
- `FREE_SHIPPING_CENTS`: optional, default `7500`

## Payment note

The current checkout records an order and lets you confirm payment manually.
That keeps the first deployment free and simple. For real card payments, connect
Stripe Checkout or another payment provider before taking live payments.
