const flashStack = document.querySelector(".flash-stack");

if (flashStack) {
  window.setTimeout(() => {
    flashStack.style.opacity = "0";
    flashStack.style.transform = "translateY(-0.5rem)";
  }, 3200);

  window.setTimeout(() => {
    flashStack.remove();
  }, 3900);
}

document.querySelectorAll(".filters select").forEach((select) => {
  select.addEventListener("change", () => {
    select.form?.requestSubmit();
  });
});

document.querySelectorAll(".filters input[type='radio']").forEach((radio) => {
  radio.addEventListener("change", () => {
    radio.form?.requestSubmit();
  });
});
